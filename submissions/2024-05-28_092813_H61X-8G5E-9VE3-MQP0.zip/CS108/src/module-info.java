module ChaCuN {
    requires javafx.controls;
    requires java.net.http;
    requires java.desktop;

    exports ch.epfl.chacun;
    exports ch.epfl.chacun.gui;
    exports ch.epfl.fxtest;
}